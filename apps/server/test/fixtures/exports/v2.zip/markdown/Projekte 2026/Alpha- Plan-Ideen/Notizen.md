---
id: 76556182-d592-4bbe-ada6-8126c8def59b
title: "Notizen"
tags: ["projekt"]
favorite: false
created_at: "2026-10-07T21:32:39.556Z"
updated_at: "2026-10-07T21:32:39.617Z"
---

Zurück zu [Projekte](../../Projekte%202026.md)
