---
id: 0a702e3e-6378-4fce-b59a-41c6f323bdd2
title: "Projekte 2026"
tags: ["projekt"]
favorite: true
created_at: "2026-10-07T21:32:39.556Z"
updated_at: "2026-10-07T21:32:39.570Z"
---

# Überblick

## Details

- Mehr dazu

  Im Toggle

> ⚠️ Hinweis

---

### Klein

**fett**, _kursiv_, `code`, [Web](https://example.com) und [Notizen](Projekte%202026/Alpha-%20Plan-Ideen/Notizen.md)

- Punkt
  1. Unterpunkt

> Zitat
> zweite Zeile

```ts
const x = `a` // [kein](page:link)
```

- [x] Erledigt
  - [ ] Offen
