---
id: c4a4eb44-9bab-43e1-907b-a86724a4ca77
title: "Projekte 2026"
tags: ["projekt"]
favorite: true
icon: "📁"
created_at: "2026-10-07T21:51:51.868Z"
updated_at: "2026-10-07T21:51:51.929Z"
---

# Überblick

## Details

- Mehr dazu

  Im Toggle

> ⚠️ Hinweis

---

### Klein

**fett**, _kursiv_, `code`, [Web](https://example.com) und [Notizen](Projekte%202026/Alpha-%20Plan-Ideen/Notizen.md)

- Punkt
  1. Unterpunkt

> Zitat
> zweite Zeile

```ts
const x = `a` // [kein](page:link)
```

- [x] Erledigt
  - [ ] Offen
