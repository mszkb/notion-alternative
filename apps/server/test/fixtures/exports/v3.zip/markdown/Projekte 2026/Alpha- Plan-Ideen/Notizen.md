---
id: 18fbbcef-1dfa-43b1-8b1c-5355f2679986
title: "Notizen"
tags: ["projekt"]
favorite: false
created_at: "2026-10-07T21:51:51.868Z"
updated_at: "2026-10-07T21:51:51.927Z"
---

Zurück zu [Projekte](../../Projekte%202026.md)
