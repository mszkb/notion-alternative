---
id: 36f18ab6-fd60-44ab-957a-2b69b3f502cb
title: "Projekte 2026"
tags: ["projekt"]
favorite: true
created_at: "2026-10-03T13:37:54.828Z"
updated_at: "2026-10-03T13:37:54.844Z"
---

# Überblick

## Details

### Klein

**fett**, _kursiv_, `code`, [Web](https://example.com) und [Notizen](Projekte%202026/Alpha-%20Plan-Ideen/Notizen.md)

- Punkt
  1. Unterpunkt

> Zitat
> zweite Zeile

```ts
const x = `a` // [kein](page:link)
```
