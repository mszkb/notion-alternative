---
id: 19c5548e-c02d-4b50-a9a2-a0c5d76b4983
title: "Notizen"
tags: ["projekt"]
favorite: false
created_at: "2026-10-03T13:37:54.828Z"
updated_at: "2026-10-03T13:37:54.884Z"
---

Zurück zu [Projekte](../../Projekte%202026.md)
